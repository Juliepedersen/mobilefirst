# Multimediedesigner 1. semester

## Materialer til multimediedesignere 1. sem. efteråret 2021 (hold D og E)

På dette repo finder du boilerplates og eksempler fra undervisningen. Boilerplates kan bruges igen og igen, gør sådan:

1. Klon dette repo via Github Desktop (fx)
2. Kopier de mapper du får brug for til en ny mappe.



/ petj
